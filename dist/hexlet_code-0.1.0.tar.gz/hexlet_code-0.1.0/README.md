### Hexlet tests and linter status:
[![Actions Status](https://github.com/DashaHadeeva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DashaHadeeva/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e56d379337b9f608d521/maintainability)](https://codeclimate.com/github/DashaHadeeva/python-project-49/maintainability)